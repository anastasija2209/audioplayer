class Model:
    def __init__(self):
        self.__playlist = []

    @property
    def playlist(self):
        return self.__playlist

    def get_audio(self, index):
        return self.__playlist[index]

    def add_to_playlist(self, audio_file):
        self.__playlist.append(audio_file)

    def remove_from_playlist(self, index):
        del self.__playlist[index]

    def clear_playlist(self):
        self.__playlist.clear()