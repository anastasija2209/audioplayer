import pyglet

FORWARD_REWIND_TIME = 20  # sekundi

class AudioPlayer:
    def __init__(self):
        self.reset_player()
        self.player.volume = 0.6

    def reset_player(self):
        """
        Resetira trenutni player (pauzira, briše) i stvara novi player.
        Također postavlja self.source na None, jer nema učitanog audio izvora.
        """
        try:
            self.player.pause()
            self.player.delete()
        except Exception:
            pass
        self.player = pyglet.media.Player()
        self.player.volume = 0.6
        self.source = None

    def play(self, audio_file):
        self.reset_player()
        try:
            self.source = pyglet.media.load(audio_file)
            print("Audio file loaded. Duration:", self.source.duration)
        except Exception as e:
            print("Error loading audio file:", e)
            return
        self.player.queue(self.source)
        self.player.play()

    def stop(self):
        """ Zaustavlja reproduciranje resetiranjem playera. """
        self.reset_player()

    def pause(self):
        """ Pauzira reproduciranje. """
        self.player.pause()

    def unpause(self):
        """ Nastavlja reproduciranje. """
        self.player.play()

    def seek(self, time):
        """
        Pomiče reproduciranje na zadano vrijeme (u sekundama).
        """
        try:
            self.player.seek(time)
        except Exception as e:
            print("Error seeking:", e)

    def fast_forward(self):
        """ Pomiče reproduciranje unaprijed za FORWARD_REWIND_TIME sekundi. """
        new_time = self.player.time + FORWARD_REWIND_TIME
        if new_time < self.track_length:
            self.seek(new_time)
        else:
            self.seek(self.track_length)

    def rewind(self):
        """ Pomiče reproduciranje unazad za FORWARD_REWIND_TIME sekundi. """
        new_time = max(0, self.player.time - FORWARD_REWIND_TIME)
        self.seek(new_time)

    def mute(self):
        """ Postavlja volumen na 0, ali čuva prethodni volumen u _prev_volume. """
        self._prev_volume = self.player.volume
        self.player.volume = 0

    def unmute(self, previous_volume):
        """ Vraća prethodno zabilježeni volumen. """
        self.player.volume = previous_volume

    @property
    def elapsed_time(self):
        return self.player.time

    @property
    def track_length(self):
        """
        Vraća ukupnu dužinu audio datoteke.
        Ako audio nije učitan (self.source je None), vraća 0.
        """
        if self.source is None:
            return 0
        return self.source.duration

    @property
    def volume(self):
        """ Vraća trenutnu vrijednost volumena. """
        return self.player.volume

    @volume.setter
    def volume(self, value):
        self.player.volume = value

    def is_playing(self):
        """ Vraća True ako je player aktivno reproducirao audio. """
        try:
            return self.player.playing
        except Exception:
            return False