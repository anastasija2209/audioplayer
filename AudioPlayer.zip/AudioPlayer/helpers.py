def get_time_in_min_sec(seconds):
    minutes = int(seconds // 60)
    seconds = int(seconds % 60)
    return minutes, seconds

def truncate_text(text, length):
    return text if len(text) <= length else text[:length] + "..."