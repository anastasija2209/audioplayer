import os
import itertools
import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog
from PIL import Image
import pyglet

from helpers import get_time_in_min_sec, truncate_text

BASE_DIR = os.path.join(os.path.expanduser("~"), "Desktop", "AudioPlayer")
ICON_DIR = os.path.join(BASE_DIR, "icons")

class AudioPlayerView:
    def __init__(self, root, model, player):
        self.root = root
        self.model = model
        self.player = player

        self.root.title("AudioPlayer")
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        self.root.state("zoomed")
        icon_path = os.path.join(ICON_DIR, "note.png")
        self.default_cover_image = ctk.CTkImage(Image.open(icon_path), size=(250, 250))
        self.root.iconphoto(False, tk.PhotoImage(file=icon_path))

        self.toggle_play_stop = itertools.cycle(["play", "stop"])
        self.toggle_pause_unmute = itertools.cycle(["pause", "unmute"])
        self.toggle_mute_unmute = itertools.cycle(["mute", "unmute"])
        self.current_track_index = 0

        self.load_images()
        self.create_widgets()

        self.root.protocol("WM_DELETE_WINDOW", self.close_player)
        self.root.after(100, self.periodic_update)
        self.root.bind("<Configure>", self.on_resize)

    def load_images(self):
        self.icons = {}
        for key in ["prev", "rewind", "play", "stop", "pause", "fast_forward", "next", "mute", "unmute", "shuffle"]:
            icon_path = os.path.join(ICON_DIR, f"{key}.png")
            if os.path.exists(icon_path):
                self.icons[key] = ctk.CTkImage(Image.open(icon_path), size=(32, 32))
            else:
                self.icons[key] = None

    def create_widgets(self):
        self.main_frame = ctk.CTkFrame(self.root, fg_color="#131318", corner_radius=0)
        self.main_frame.pack(fill="both", expand=True, padx=0, pady=0)

        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_columnconfigure(1, weight=2)
        self.main_frame.grid_rowconfigure(0, weight=1)

        self.left_frame = ctk.CTkFrame(self.main_frame, width=300, fg_color="#1e1e2f", corner_radius=0)
        self.left_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.create_playlist_panel()

        self.right_frame = ctk.CTkFrame(self.main_frame, fg_color="#1e1e2f", corner_radius=0)
        self.right_frame.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)
        self.create_playback_panel()

    def create_playlist_panel(self):
        title_label = ctk.CTkLabel(self.left_frame, text="Playlist", font=("Segoe UI", 24, "bold"))
        title_label.pack(pady=10)

        self.playlist_box = tk.Listbox(
            self.left_frame, font=("Segoe UI", 16), bg="#1e1e2f", fg="#ffffff",
            selectbackground="#3e3e55", relief="flat", highlightthickness=0, bd=0)
        self.playlist_box.pack(fill="both", expand=True, padx=10, pady=10)
        self.playlist_box.bind("<Double-Button-1>", self.on_playlist_double_click)

        btn_frame = ctk.CTkFrame(self.left_frame, fg_color="transparent")
        btn_frame.pack(pady=15)
        self.btn_add_file = ctk.CTkButton(btn_frame, text="Add File", corner_radius=15, command=self.on_add_file)
        self.btn_add_file.grid(row=0, column=0, padx=5, pady=5)
        self.btn_delete = ctk.CTkButton(btn_frame, text="Delete", corner_radius=15, command=self.on_delete_file)
        self.btn_delete.grid(row=0, column=1, padx=5, pady=5)
        self.btn_clear = ctk.CTkButton(btn_frame, text="Clear", corner_radius=15, command=self.on_clear_playlist)
        self.btn_clear.grid(row=0, column=2, padx=5, pady=5)

    def create_playback_panel(self):
        container = ctk.CTkFrame(self.right_frame, fg_color="transparent")
        container.pack(expand=True)

        self.track_label = ctk.CTkLabel(container, text="Now Playing: None", font=("Segoe UI", 28, "bold"))
        self.track_label.pack(pady=10)

        self.album_cover_label = ctk.CTkLabel(container, image=self.default_cover_image, text="")
        self.album_cover_label.pack(pady=10)

        timer_frame = ctk.CTkFrame(container, fg_color="transparent")
        timer_frame.pack(pady=10, fill="x")
        self.clock_label = ctk.CTkLabel(timer_frame, text="00:00", font=("Segoe UI", 18))
        self.clock_label.pack(side="left", padx=10)
        self.duration_label = ctk.CTkLabel(timer_frame, text="of 00:00", font=("Segoe UI", 18))
        self.duration_label.pack(side="left", padx=10)
        self.progress_slider = ctk.CTkSlider(container, from_=0, to=100, number_of_steps=100)
        self.progress_slider.set(0)
        self.progress_slider.configure(command=self.on_progress_slider_changed)
        self.progress_slider.pack(pady=10, fill="x", padx=20)

        control_frame = ctk.CTkFrame(container, fg_color="transparent")
        control_frame.pack(pady=10)
        self.btn_prev = ctk.CTkButton(control_frame, text="", image=self.icons.get("prev"),
                                      width=40, height=40, corner_radius=20, command=self.on_prev)
        self.btn_prev.grid(row=0, column=0, padx=8)
        self.btn_rewind = ctk.CTkButton(control_frame, text="", image=self.icons.get("rewind"),
                                        width=40, height=40, corner_radius=20, command=self.on_rewind)
        self.btn_rewind.grid(row=0, column=1, padx=8)
        self.btn_play = ctk.CTkButton(control_frame, text="", image=self.icons.get("play"),
                                      width=40, height=40, corner_radius=20, command=self.on_play_stop)
        self.btn_play.grid(row=0, column=2, padx=8)
        self.btn_pause = ctk.CTkButton(control_frame, text="", image=self.icons.get("pause"),
                                       width=40, height=40, corner_radius=20, command=self.on_pause_unmute)
        self.btn_pause.grid(row=0, column=3, padx=8)
        self.btn_ff = ctk.CTkButton(control_frame, text="", image=self.icons.get("fast_forward"),
                                    width=40, height=40, corner_radius=20, command=self.on_fast_forward)
        self.btn_ff.grid(row=0, column=4, padx=8)
        self.btn_next = ctk.CTkButton(control_frame, text="", image=self.icons.get("next"),
                                      width=40, height=40, corner_radius=20, command=self.on_next)
        self.btn_next.grid(row=0, column=5, padx=8)
        self.btn_shuffle = ctk.CTkButton(control_frame, text="", image=self.icons.get("shuffle"),
                                         width=40, height=40, corner_radius=20, command=self.on_shuffle)
        self.btn_shuffle.grid(row=0, column=6, padx=8)

        volume_frame = ctk.CTkFrame(container, fg_color="transparent")
        volume_frame.pack(pady=(30, 10))

        self.btn_mute = ctk.CTkButton(volume_frame, text="", image=self.icons.get("unmute"),
                                      width=40, height=40, corner_radius=20, command=self.on_mute_unmute)
        self.btn_mute.pack(side="left", padx=(0, 10))

        self.volume_scale = ctk.CTkSlider(volume_frame, from_=0, to=1, width=200, command=self.on_volume_change)
        self.volume_scale.set(0.6)
        self.volume_scale.pack(side="left")

    def on_add_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("Audio Files", "*.mp3 *.wav")])
        if file_path:
            self.model.add_to_playlist(file_path)
            self.playlist_box.insert(tk.END, os.path.basename(file_path))

    def on_delete_file(self):
        selection = self.playlist_box.curselection()
        for index in reversed(selection):
            self.playlist_box.delete(index)
            self.model.remove_from_playlist(index)

    def on_clear_playlist(self):
        self.model.clear_playlist()
        self.playlist_box.delete(0, tk.END)

    def on_playlist_double_click(self, event):
        try:
            self.current_track_index = int(self.playlist_box.curselection()[0])
        except IndexError:
            self.current_track_index = 0
        self.start_playback()

    def on_prev(self):
        self.current_track_index = max(0, self.current_track_index - 1)
        self.start_playback()

    def on_rewind(self):
        self.player.rewind()

    def on_play_stop(self):
        action = next(self.toggle_play_stop)
        if action == "play":
            try:
                self.current_track_index = self.playlist_box.curselection()[0]
            except IndexError:
                self.current_track_index = 0
            self.start_playback()
        elif action == "stop":
            self.player.stop()
            self.btn_play.configure(image=self.icons.get("play"))

    def on_pause_unmute(self):
        action = next(self.toggle_pause_unmute)
        if action == "pause":
            self.player.pause()
        elif action == "unmute":
            self.player.unpause()

    def on_fast_forward(self):
        self.player.fast_forward()

    def on_next(self):
        self.current_track_index = min(self.playlist_box.size() - 1, self.current_track_index + 1)
        self.start_playback()

    def on_mute_unmute(self):
        action = next(self.toggle_mute_unmute)
        if action == "mute":
            self.volume_at_mute = self.player.volume
            self.player.mute()
            self.volume_scale.set(0)
            self.btn_mute.configure(image=self.icons.get("mute"))
        elif action == "unmute":
            self.player.unmute(self.volume_at_mute)
            self.volume_scale.set(self.volume_at_mute)
            self.btn_mute.configure(image=self.icons.get("unmute"))

    def on_volume_change(self, value):
        vol = float(value)
        self.player.volume = vol
        if vol == 0.0:
            self.btn_mute.configure(image=self.icons.get("mute"))
        else:
            self.btn_mute.configure(image=self.icons.get("unmute"))

    def on_progress_slider_changed(self, value):
        if self.player.track_length:
            new_time = float(value) / 100 * self.player.track_length
            self.player.seek(new_time)

    def start_playback(self):
        try:
            audio_file = self.model.get_audio(self.current_track_index)
        except IndexError:
            return
        self.btn_play.configure(image=self.icons.get("stop"))
        self.player.play(audio_file)
        self.update_now_playing()
        self.update_track_duration()

    def update_now_playing(self):
        filename = os.path.basename(self.model.playlist[self.current_track_index])
        self.track_label.configure(text=f"Now Playing: {truncate_text(filename, 40)}")
        self.album_cover_label.configure(image=self.default_cover_image)

    def update_track_duration(self):
        duration = self.player.track_length
        minutes, seconds = get_time_in_min_sec(duration)
        self.duration_label.configure(text=f"of {minutes:02d}:{seconds:02d}")

    def periodic_update(self):
        pyglet.clock.tick()
        print("Elapsed:", self.player.elapsed_time, "Track length:", self.player.track_length)
        self.update_clock()
        self.update_progress_slider()
        self.root.after(100, self.periodic_update)

    def update_clock(self):
        elapsed = self.player.elapsed_time
        minutes, seconds = get_time_in_min_sec(elapsed)
        self.clock_label.configure(text=f"{minutes:02d}:{seconds:02d}")

    def update_progress_slider(self):
        if self.player.track_length:
            percent = (self.player.elapsed_time / self.player.track_length) * 100
        else:
            percent = 0
        self.progress_slider.set(percent)

    def on_resize(self, event):
        new_width = event.width if event.width >= 300 else 300
        if new_width < 800:
            new_font = ("Segoe UI", 14, "bold")
        else:
            new_font = ("Segoe UI", 28, "bold")
        self.track_label.configure(font=new_font)

    def close_player(self):
        self.player.stop()
        self.root.destroy()

    def on_shuffle(self):
        import random
        if self.model.playlist:
            random.shuffle(self.model.playlist)
            self.playlist_box.delete(0, tk.END)
            for file in self.model.playlist:
                self.playlist_box.insert(tk.END, os.path.basename(file))
