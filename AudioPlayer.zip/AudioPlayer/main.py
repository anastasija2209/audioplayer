import tkinter as tk
from view import AudioPlayerView
from model import Model
from player import AudioPlayer

def main():
    root = tk.Tk()
    root.minsize(800, 600)
    app = AudioPlayerView(root, Model(), AudioPlayer())
    root.mainloop()

if __name__ == "__main__":
    main()