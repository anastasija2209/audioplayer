import tkinter as tk

class SeekBar(tk.Canvas):
    def __init__(self, parent, width=400, height=10, **kwargs):
        super().__init__(parent, width=width, height=height, **kwargs)
        self.width = width
        self.height = height
        self.bar = self.create_rectangle(0, 0, 0, height, fill="red")
        self.knob_img = tk.PhotoImage(file="icons/seekbar_knob.png")
        self.knob = self.create_image(0, height//2, image=self.knob_img, anchor="center")
        self.bind("<Button-1>", self.on_click)
        self.bind("<B1-Motion>", self.on_click)

    def on_click(self, event):
        x = event.x
        if 0 <= x <= self.width:
            self.slide_to(x)
            self.event_generate("<<SeekbarChanged>>", x=x)

    def slide_to(self, x):
        self.coords(self.bar, 0, 0, x, self.height)
        self.coords(self.knob, x, self.height // 2)